using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floater : MonoBehaviour
{
    private Vector3 startPosition;  // Definir variable para obtener posici�n inicial de Objeto
    public float floatSpeed = 0f;  // Definir variable p�blica tipo float (numero) para establecer Velocidad de la flotaci�n del objeto
    public float floatAmplitude = 0f;  // Definir variable p�blica tipo float (numero) para establecer Amplitud de la flotaci�n del objeto

    void Start()
    {
        startPosition = transform.position;  // Obtener la posici�n inicial del objeto (para calculo posterior de flotaci�n) en los 3 ejes
    }

    void Update()
    {
        float newY = startPosition.y + Mathf.Sin(Time.time * floatSpeed) * floatAmplitude;  // Calcular la nueva posici�n para el efecto de flotaci�n en eje Y
        
        transform.position = new Vector3(startPosition.x, newY, startPosition.z);  // Aplicar la nueva posici�n al objeto de forma constante
    }
}
