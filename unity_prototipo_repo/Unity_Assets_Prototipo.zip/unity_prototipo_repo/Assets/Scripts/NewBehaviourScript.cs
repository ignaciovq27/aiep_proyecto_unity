using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // FUNCTIONS
    // void: Indica que las funciones no retornan valores
    // "Start" es llamada una vez antes del primer frame de la funci�n "Update"
    void Start()
    {

    }

    // "FixedUpdate" es llamada antes de realizar calculos de f�sica en la escena de juego
    void FixedUpdate()
    {

    }

    // "Update" es llamada una vez por cada frame de ejecuci�n de juego
    void Update()
    {

    }
}
